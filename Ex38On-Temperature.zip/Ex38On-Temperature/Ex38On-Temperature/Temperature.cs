﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ex38On_Temperature
{
    public enum Unit
    {
        Celsius,
        Fahrenheit
    }
    class Temperature {

        public double Celsius
        {
            get
            {
                return temp;
            }
            internal set
            {
                temp = value;
            }
        }
        public double Fahrenheit {
            get
            {
                return temp;
            }
            internal set
            {
                temp = value;
            }
        }

        //private object temperatureType;
        private Unit temperaturetype;
        private double temp;

        public Temperature(Unit temperaturetype, double temp)
        {
            this.temperaturetype = temperaturetype;
            this.temp = temp;
        }

        public Temperature()
        {
        }

        internal static double FahrenheitToCelsius(double temperature)
        {
            double conversion = Math.Ceiling((temperature - 32) / 1.8);
            return (int)conversion;
        }

        internal static double CelsiusToFahrenheit(double temperature)
        {
            double conversion = temperature * 9/5 + 32;
            return conversion;
        }
    }
}
