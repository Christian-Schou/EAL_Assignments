﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex38On_Temperature
{
    class Program
    {
        static void Main(string[] args)
        {
            var temp = new Temperature(Unit.Celsius, 20);
            Console.WriteLine(temp);
            Console.ReadLine();
        }
    }
}
