﻿using System;

namespace Ex38On_Temperature
{
    internal class Celsius : ITemperature
    {
        public double Convert(double temp)
        {
            return (temp - 32) * 5 / 9;

        }
    }
}