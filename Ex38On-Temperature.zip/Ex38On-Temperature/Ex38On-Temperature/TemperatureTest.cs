﻿using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace Ex38On_Temperature
{
    [TestClass]
    public class TemperatureTest
    {
        

        //STATIC CLASSES

        //Fahrenheit to celcius

        [TestMethod]
        public void ConvertFreezingTemperatureFTOC()
        {
            Assert.AreEqual(0, Temperature.FahrenheitToCelsius(32));
        }

        [TestMethod]
        public void ConvertBoilingTemperatureFTOC()
        {
            Assert.AreEqual(100, Temperature.FahrenheitToCelsius(212));
        }
        [TestMethod]
        public void ConvertBodyTemperatureFTOC()
        {
            Assert.AreEqual(37, Temperature.FahrenheitToCelsius(98.6));
        }
        [TestMethod]
        public void ConvertAbitraryTemperatureFTOC()
        {
            Assert.AreEqual(20, Temperature.FahrenheitToCelsius(68));
        }

        //Celsius to Fahrenheit
        [TestMethod]
        public void ConvertFreezingTemperatureCTOF()
        {
            Assert.AreEqual(32, Temperature.CelsiusToFahrenheit(0));
        }
        [TestMethod]
        public void ConvertBoilingTemperatureCTOF()
        {
            Assert.AreEqual(212, Temperature.CelsiusToFahrenheit(100));
        }
        [TestMethod]
        public void ConvertBodyTemperatureCTOF()
        {
            Assert.AreEqual(98.6, Temperature.CelsiusToFahrenheit(37));
        }
        [TestMethod]
        public void ConvertArbitraryTemperatureCTOF()
        {
            Assert.AreEqual(68, Temperature.CelsiusToFahrenheit(20));
        }

        //INSTANCE CLASSES

        //Through properties & constructors


        [TestMethod]
        public void CanSaveDataInFahrenheitProperty()
        {
            var temp = new Temperature();
            temp.Fahrenheit = 32;
            Assert.AreEqual(32, temp.Fahrenheit);
        }
        [TestMethod]
        public void CanSaveDataInCelsiusProperty()
        {
            var temp = new Temperature();
            temp.Celsius = 0;
            Assert.AreEqual(0, temp.Celsius);
        }
        [TestMethod]
        public void CanBeConstructedViaConstructor()
        {
            var temp = new Temperature(Unit.Celsius, 20); //Use Enum
            Assert.AreEqual(20, temp.Celsius);

            temp = new Temperature(Unit.Fahrenheit, 20); //Use Enum
            Assert.AreEqual(20, temp.Fahrenheit);
        }



        // FACTORY CLASSES
        //
        //Test driven bonus.If you have read about factory methods try solving the problem below

      [TestMethod]
        public void CanBeConstructedViaFactoryMethod()
        {
            ITemperature temp = TemperatureFactory.Get(Unit.Celsius); //Use Enum
            Assert.IsInstanceOfType(temp, typeof(Celsius)); //Pay attention to the order of the parameters in IsInstanceOfType
        }
        [TestMethod]
        public void FactoryMethodConvertsCorrectlyFromFahrenheitToCelsius()
        {
            ITemperature temp = TemperatureFactory.Get(Unit.Celsius); //Use Enum
            Assert.AreEqual(100, (temp as Celsius).Convert(212));
            Assert.AreEqual(100, temp.Convert(212));
        }
        [TestMethod]
        public void FactoryMethodConvertsCorrectlyFromCelsiusToFahrenheit()
        {
            ITemperature temp = TemperatureFactory.Get(Unit.Fahrenheit); //Use Enum
            Assert.AreEqual(212, (temp as Fahrenheit).Convert(100));
            Assert.AreEqual(212, temp.Convert(100));
        }

    }
}
