﻿using System;

namespace Ex38On_Temperature
{
    internal class TemperatureFactory
    {
        internal static ITemperature Get(Unit unit)
        {
            switch (unit)
            {
                case Unit.Celsius:

                    ITemperature cel = new Celsius();
                    return cel;

                case Unit.Fahrenheit:

                    ITemperature far = new Fahrenheit();
                    return far;

                default:
                    throw new Exception();

            }
        }
    }
}