﻿namespace Ex38On_Temperature
{
    internal interface ITemperature
    {
        double Convert(double v);
    }
}