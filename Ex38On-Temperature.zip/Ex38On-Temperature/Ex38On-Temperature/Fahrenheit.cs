﻿using System;

namespace Ex38On_Temperature
{
    internal class Fahrenheit : ITemperature
    {
            public double Convert(double temp)
            {
                return (temp * 9 / 5) + 32;
            }
        
    }
}