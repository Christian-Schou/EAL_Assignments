﻿using System;
using System.Collections.Generic;

namespace Book_Titles
{
    internal class Book
    {

        private string bookTitle = "N/A";
        public string Title
        {
            get
            {
                return bookTitle;
            }
            set
            {
                string[] title = value.Split(new char[] { ' ','\t'}, StringSplitOptions.RemoveEmptyEntries);
                title[0] = Capitalize(title[0]);
                for (int i = 1; i < title.Length; i++)
                {
                    title[i] = CapitalizeCheck(title[i]);
                }
                bookTitle = String.Join(" ", title);
            }
        }

        private string CapitalizeCheck(string v)
        {
            List<string> words = new List<string>();
            string[] tempWords = { "the", "a", "an", "in", "of", "and" };
            words.AddRange(tempWords);
            if(!words.Contains(v))
            {
                return Capitalize(v);
            }else
            {
                return v;
            }
        }

        private string Capitalize(string v)
        {
            return (v[0].ToString().ToUpper() + v.Substring(1));
        }



    }
}